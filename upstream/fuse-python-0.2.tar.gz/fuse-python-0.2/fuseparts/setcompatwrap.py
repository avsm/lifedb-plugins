try:
  set()
  set = set
except:
  from sets import Set as set
