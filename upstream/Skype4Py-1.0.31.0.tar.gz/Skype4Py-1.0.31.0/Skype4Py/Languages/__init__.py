'''
Copyright (c) 2007, Arkadiusz Wahlig

All rights reserved.

Distributed under the BSD License, see the
accompanying LICENSE file for more information.
'''

# This file is needed only when building executable files using py2exe.
# It is imported by Skype4Py.conversion and makes sure that all languages
# are included in the package built by py2exe. The tool lookes just at
# the imports, it ignores the 'if' statement.
#
# More about py2exe: http://www.py2exe.org/


if False:
    import ar
    import bg
    import cs
    import cz
    import da
    import de
    import el
    import en
    import en
    import es
    import et
    import fi
    import fr
    import he
    import hu
    import it
    import ja
    import ko
    import lt
    import lv
    import nl
    import no
    import pl
    import pl
    import pp
    import pt
    import ro
    import ru
    import sv
    import tr
    import x1
